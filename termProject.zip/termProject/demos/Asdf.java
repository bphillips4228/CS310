import edu.jsu.mcis.*;

public class Asdf{
	
	Parser p;
	
	public Asdf(){
		p = new Parser();
	}
	
	public static void main(String[] args){
		Asdf asdf = new Asdf();
		String[] values = {"--type", "box"};
		asdf.p.parseValues(values);
	}

}