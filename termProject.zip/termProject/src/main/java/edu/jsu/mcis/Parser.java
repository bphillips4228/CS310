package edu.jsu.mcis;
import java.util.*;
import java.lang.*;

public class Parser{
	
	private List<Argument> argumentList;
	private List<Argument> optionalArgumentsList;
	private String helpMessage;
	private String programName;
	
	public Parser(){
		argumentList = new ArrayList<Argument>();
		optionalArgumentsList = new ArrayList<Argument>();
		}
	
	public void addArguments(String[] args){
		for(int i = 0; i < args.length; i++){
			argumentList.add(new Argument(args[i], "String"));
		}
	}
	
	public void addArgument(String arg){
		argumentList.add(new Argument(arg, "String"));
	}
	
	public void addArgument(String name, String valueType, String value){
		argumentList.add(new Argument(name, valueType, value));
	}
	
	public void addArgument(String name, String valueType){
		argumentList.add(new Argument(name, valueType));
	}
	
	public void addOptionalArguments(String[] args){
		for(int i = 0; i < args.length; i++){
			optionalArgumentsList.add(new Argument(args[i], "String"));
		}
	}
	
	public void addOptionalArgument(String arg){
		optionalArgumentsList.add(new Argument(arg, "String"));
	}
	
	public void addOptionalArgument(String name, String valueType){
		optionalArgumentsList.add(new Argument(name, valueType));
	}
	
	public void addOptionalArgument(String name, String valueType, String value){
		optionalArgumentsList.add(new Argument(name, valueType, value));
	}
	
	
	
	public boolean containsName(String arg){
		for(int i = 0; i < argumentList.size(); i++){
			if(argumentList.get(i).getName().equals(arg))
				return true;
		}
		return false;
	}
	
	public void parseValues(String[] args){
		int count = 0;
		
		for(int i = 0; i < args.length; i++){
			if(args[i].equals("-h") || args[i].equals("--help"))
				throw new HelpException(programName, helpMessage);
		}
		
		for(int i = 0; i < args.length; i++){
			if(args[i].charAt(0) == '-' && args[i].charAt(1) == '-'){
				count++;
				String argument = args[i].replace("-", "");
				int j = getIndex(argument);
				if(j > -1){
					optionalArgumentsList.get(j).setValue(args[i+1]);
					count++;
				}
					
			}
		}
		
		if(args.length > argumentList.size() + count){
				String extraArgs = "";
				for(int i = argumentList.size(); i < args.length; i++) {
					extraArgs += args[i];
				}
				throw new TooManyArgsException(extraArgs);
		}
		
		else if(args.length < argumentList.size() + count){
				String extraArgs = "";
				for(int i = args.length; i < argumentList.size(); i++){
					extraArgs += argumentList.get(i).getName();
				}
				throw new TooFewArgsException(extraArgs);
		}
		
		for(int i = 0; i < argumentList.size(); i++){
			String argList = "";
			argumentList.get(i).setValue(args[i]);
			if(!checkValueType(argumentList.get(i).getName())){
				for(int j = 0; j < argumentList.size(); j++){
					String temp = argumentList.get(j).getName();
					argList += temp + " ";
				}
				throw new WrongTypeException(argumentList.get(i).getValue(), argumentList.get(i).getValueType(), programName, argList, argumentList.get(i).getName());
			}
		}

	}
	
	public String getValue(String arg){
		for(int i = 0; i < argumentList.size(); i++){
			if(argumentList.get(i).getName().equals(arg))
				return argumentList.get(i).getValue();
		}
		
		return "";
	}
	
	public String getOptionalValue(String arg){
		for(int i = 0; i < optionalArgumentsList.size(); i++){
			if(optionalArgumentsList.get(i).getName().equals(arg))
				return optionalArgumentsList.get(i).getValue();
		}
		
		return "";
	}
	
	private int getIndex(String arg){
		for(int i = 0; i < optionalArgumentsList.size(); i++){
			if(optionalArgumentsList.get(i).getName().equals(arg))
				return i;
		}
		return -1;
	}
	
	private boolean checkValueType(String arg){
		for(int i = 0; i < argumentList.size(); i++){
			if(argumentList.get(i).getName().equals(arg)){
				String argType = argumentList.get(i).getValueType();
				int tempInt;
				float tempFloat;
				if(argType.equals("boolean")){
					if(argumentList.get(i).getValue().equals("true") || argumentList.get(i).getValue().equals("false"))
						return true;
					else 
						return false;
				}
				
				else if(argType.equals("int")){
					try{
						tempInt = Integer.parseInt(argumentList.get(i).getValue());
					} catch(NumberFormatException ex){
						return false;
					}
					return true;
				}
				
				else if(argType.equals("float")){
					try{
						tempFloat = Float.parseFloat(argumentList.get(i).getValue());
					} catch(NumberFormatException ex){
						return false;
					}
					return true;
				}
				
				else if(argType.equals("String")){
					return true;
				}
				
				else 
					return false;
				
			}
		}
		return false;
	}
	
	public void setHelpMessage(String helpMessage){
		this.helpMessage = helpMessage;
	}
	
	public void setProgramName(String name){
		this.programName = name;
	}
}
	